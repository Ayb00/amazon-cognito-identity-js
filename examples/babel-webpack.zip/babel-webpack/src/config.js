export default {
    region: 'us-east-1',
    IdentityPoolId: 'us-east-1:5fb40640-61d2-4e1e-9d9e-69f198e997ac',
    UserPoolId: 'us-east-1_y8xpCfj4L',
    ClientId: '4uen0122a0dl1a9pvq4bfolcui',
}